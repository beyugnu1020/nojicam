import React, { useState } from 'react';

function App() {
  const [tab, setTab] = useState("home");

  return (
    <div className="min-h-screen p-4 bg-gray-100">
      <h1 className="text-2xl font-bold mb-4">노지어때</h1>
      <div className="space-x-2 mb-6">
        <button onClick={() => setTab("home")} className="bg-blue-500 text-white px-4 py-2 rounded">홈</button>
        <button onClick={() => setTab("map")} className="bg-blue-500 text-white px-4 py-2 rounded">장소 등록</button>
        <button onClick={() => setTab("mypage")} className="bg-blue-500 text-white px-4 py-2 rounded">마이페이지</button>
      </div>
      <div>
        {tab === "home" && <div>🏕 모두의 노지 캠핑장 공유 플랫폼!</div>}
        {tab === "map" && <div>📍 장소 등록 지도 컴포넌트</div>}
        {tab === "mypage" && <div>👤 마이페이지 정보</div>}
      </div>
    </div>
  );
}

export default App;
